/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/fireWatcher";
exports.ids = ["pages/fireWatcher"];
exports.modules = {

/***/ "./styles/FireWatcher.module.css":
/*!***************************************!*\
  !*** ./styles/FireWatcher.module.css ***!
  \***************************************/
/***/ ((module) => {

eval("// Exports\nmodule.exports = {\n\t\"container\": \"FireWatcher_container__qFK6Y\",\n\t\"main\": \"FireWatcher_main__P8wJG\",\n\t\"title\": \"FireWatcher_title__HwAlj\"\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdHlsZXMvRmlyZVdhdGNoZXIubW9kdWxlLmNzcy5qcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zdHlsZXMvRmlyZVdhdGNoZXIubW9kdWxlLmNzcz9iMDAwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEV4cG9ydHNcbm1vZHVsZS5leHBvcnRzID0ge1xuXHRcImNvbnRhaW5lclwiOiBcIkZpcmVXYXRjaGVyX2NvbnRhaW5lcl9fcUZLNllcIixcblx0XCJtYWluXCI6IFwiRmlyZVdhdGNoZXJfbWFpbl9fUDh3SkdcIixcblx0XCJ0aXRsZVwiOiBcIkZpcmVXYXRjaGVyX3RpdGxlX19Id0FsalwiXG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./styles/FireWatcher.module.css\n");

/***/ }),

/***/ "./components/FireWatcher.js":
/*!***********************************!*\
  !*** ./components/FireWatcher.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../styles/FireWatcher.module.css */ \"./styles/FireWatcher.module.css\");\n/* harmony import */ var _styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @react-google-maps/api */ \"@react-google-maps/api\");\n/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n\nconst containerStyle = {\n    width: '400px',\n    height: '400px'\n};\nconst center = {\n    lat: -3.745,\n    lng: -38.523\n};\nfunction FireWatcher() {\n    const { isLoaded  } = (0,_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.useJsApiLoader)({\n        id: 'google-map-script',\n        googleMapsApiKey: \"AIzaSyDGqF0zckys922q53176tG4gY3AM413j4w\"\n    });\n    const [map1, setMap] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);\n    const onLoad = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(function callback(map) {\n        const bounds = new window.google.maps.LatLngBounds();\n        map.fitBounds(bounds);\n        setMap(map);\n    }, []);\n    const onUnmount = react__WEBPACK_IMPORTED_MODULE_1___default().useCallback(function callback(map) {\n        setMap(null);\n    }, []);\n    return isLoaded ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: (_styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3___default().container),\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n            className: (_styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3___default().main),\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    className: (_styles_FireWatcher_module_css__WEBPACK_IMPORTED_MODULE_3___default().title),\n                    children: \"Welcome to Fire Watcher\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\components\\\\FireWatcher.js\",\n                    lineNumber: 37,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {\n                    mapContainerStyle: containerStyle,\n                    center: center,\n                    zoom: 10,\n                    onLoad: onLoad,\n                    onUnmount: onUnmount,\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false)\n                }, void 0, false, {\n                    fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\components\\\\FireWatcher.js\",\n                    lineNumber: 40,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\components\\\\FireWatcher.js\",\n            lineNumber: 36,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\components\\\\FireWatcher.js\",\n        lineNumber: 35,\n        columnNumber: 5\n    }, this) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(FireWatcher));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0ZpcmVXYXRjaGVyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBeUI7QUFDNEI7QUFDYTtBQUVsRSxLQUFLLENBQUNJLGNBQWMsR0FBRyxDQUFDO0lBQ3RCQyxLQUFLLEVBQUUsQ0FBTztJQUNkQyxNQUFNLEVBQUUsQ0FBTztBQUNqQixDQUFDO0FBRUQsS0FBSyxDQUFDQyxNQUFNLEdBQUcsQ0FBQztJQUNkQyxHQUFHLEdBQUcsS0FBSztJQUNYQyxHQUFHLEdBQUcsTUFBTTtBQUNkLENBQUM7U0FHUUMsV0FBVyxHQUNwQixDQUFDO0lBQ0MsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsUUFBUSxFQUFDLENBQUMsR0FBR1Isc0VBQWMsQ0FBQyxDQUFDO1FBQ25DUyxFQUFFLEVBQUUsQ0FBbUI7UUFDdkJDLGdCQUFnQixFQUFFLENBQXlDO0lBQzdELENBQUM7SUFFRCxLQUFLLEVBQUVDLElBQUcsRUFBRUMsTUFBTSxJQUFJZixxREFBYyxDQUFDLElBQUk7SUFFekMsS0FBSyxDQUFDaUIsTUFBTSxHQUFHakIsd0RBQWlCLENBQUMsUUFBUSxDQUFDbUIsUUFBUSxDQUFDTCxHQUFHLEVBQUUsQ0FBQztRQUN2RCxLQUFLLENBQUNNLE1BQU0sR0FBRyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFlBQVk7UUFDbERWLEdBQUcsQ0FBQ1csU0FBUyxDQUFDTCxNQUFNO1FBQ3BCTCxNQUFNLENBQUNELEdBQUc7SUFDWixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRUwsS0FBSyxDQUFDWSxTQUFTLEdBQUcxQix3REFBaUIsQ0FBQyxRQUFRLENBQUNtQixRQUFRLENBQUNMLEdBQUcsRUFBRSxDQUFDO1FBQzFEQyxNQUFNLENBQUMsSUFBSTtJQUNiLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDTCxNQUFNLENBQUNKLFFBQVEsK0VBQ1pnQixDQUFHO1FBQUNDLFNBQVMsRUFBRTNCLGlGQUFnQjs4RkFDN0I2QixDQUFJO1lBQUNGLFNBQVMsRUFBRTNCLDRFQUFXOzs0RkFDekI4QixDQUFFO29CQUFDSCxTQUFTLEVBQUUzQiw2RUFBWTs4QkFBRSxDQUU3Qjs7Ozs7OzRGQUNDQyw2REFBUztvQkFDUitCLGlCQUFpQixFQUFFN0IsY0FBYztvQkFDakNHLE1BQU0sRUFBRUEsTUFBTTtvQkFDZDJCLElBQUksRUFBRSxFQUFFO29CQUNSakIsTUFBTSxFQUFFQSxNQUFNO29CQUNkUyxTQUFTLEVBQUVBLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVE5QixDQUFDO0FBRUQsOEVBQWUxQixpREFBVSxDQUFDVSxXQUFXLENBQUMsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL2NvbXBvbmVudHMvRmlyZVdhdGNoZXIuanM/YWRhZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCBzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL0ZpcmVXYXRjaGVyLm1vZHVsZS5jc3MnXHJcbmltcG9ydCB7IEdvb2dsZU1hcCwgdXNlSnNBcGlMb2FkZXIgfSBmcm9tICdAcmVhY3QtZ29vZ2xlLW1hcHMvYXBpJztcclxuXHJcbmNvbnN0IGNvbnRhaW5lclN0eWxlID0ge1xyXG4gIHdpZHRoOiAnNDAwcHgnLFxyXG4gIGhlaWdodDogJzQwMHB4J1xyXG59O1xyXG5cclxuY29uc3QgY2VudGVyID0ge1xyXG4gIGxhdDogLTMuNzQ1LFxyXG4gIGxuZzogLTM4LjUyM1xyXG59O1xyXG5cclxuXHJcbmZ1bmN0aW9uIEZpcmVXYXRjaGVyKCkgXHJcbntcclxuICBjb25zdCB7IGlzTG9hZGVkIH0gPSB1c2VKc0FwaUxvYWRlcih7XHJcbiAgICBpZDogJ2dvb2dsZS1tYXAtc2NyaXB0JyxcclxuICAgIGdvb2dsZU1hcHNBcGlLZXk6IFwiQUl6YVN5REdxRjB6Y2t5czkyMnE1MzE3NnRHNGdZM0FNNDEzajR3XCJcclxuICB9KVxyXG5cclxuICBjb25zdCBbbWFwLCBzZXRNYXBdID0gUmVhY3QudXNlU3RhdGUobnVsbClcclxuXHJcbiAgY29uc3Qgb25Mb2FkID0gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gY2FsbGJhY2sobWFwKSB7XHJcbiAgICBjb25zdCBib3VuZHMgPSBuZXcgd2luZG93Lmdvb2dsZS5tYXBzLkxhdExuZ0JvdW5kcygpO1xyXG4gICAgbWFwLmZpdEJvdW5kcyhib3VuZHMpO1xyXG4gICAgc2V0TWFwKG1hcClcclxuICB9LCBbXSlcclxuXHJcbiAgY29uc3Qgb25Vbm1vdW50ID0gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gY2FsbGJhY2sobWFwKSB7XHJcbiAgICBzZXRNYXAobnVsbClcclxuICB9LCBbXSlcclxuICByZXR1cm4gaXNMb2FkZWQgPyhcclxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuY29udGFpbmVyfT5cclxuICAgICAgPG1haW4gY2xhc3NOYW1lPXtzdHlsZXMubWFpbn0+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT17c3R5bGVzLnRpdGxlfT5cclxuICAgICAgICAgIFdlbGNvbWUgdG8gRmlyZSBXYXRjaGVyXHJcbiAgICAgICAgPC9oMT5cclxuICAgICAgICA8R29vZ2xlTWFwXHJcbiAgICAgICAgICBtYXBDb250YWluZXJTdHlsZT17Y29udGFpbmVyU3R5bGV9XHJcbiAgICAgICAgICBjZW50ZXI9e2NlbnRlcn1cclxuICAgICAgICAgIHpvb209ezEwfVxyXG4gICAgICAgICAgb25Mb2FkPXtvbkxvYWR9XHJcbiAgICAgICAgICBvblVubW91bnQ9e29uVW5tb3VudH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7IC8qIENoaWxkIGNvbXBvbmVudHMsIHN1Y2ggYXMgbWFya2VycywgaW5mbyB3aW5kb3dzLCBldGMuICovIH1cclxuICAgICAgICAgIDw+PC8+XHJcbiAgICAgICAgPC9Hb29nbGVNYXA+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgIDwvZGl2PlxyXG4gICk6PD48Lz5cclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVhY3QubWVtbyhGaXJlV2F0Y2hlcik7XHJcbiJdLCJuYW1lcyI6WyJSZWFjdCIsInN0eWxlcyIsIkdvb2dsZU1hcCIsInVzZUpzQXBpTG9hZGVyIiwiY29udGFpbmVyU3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsImNlbnRlciIsImxhdCIsImxuZyIsIkZpcmVXYXRjaGVyIiwiaXNMb2FkZWQiLCJpZCIsImdvb2dsZU1hcHNBcGlLZXkiLCJtYXAiLCJzZXRNYXAiLCJ1c2VTdGF0ZSIsIm9uTG9hZCIsInVzZUNhbGxiYWNrIiwiY2FsbGJhY2siLCJib3VuZHMiLCJ3aW5kb3ciLCJnb29nbGUiLCJtYXBzIiwiTGF0TG5nQm91bmRzIiwiZml0Qm91bmRzIiwib25Vbm1vdW50IiwiZGl2IiwiY2xhc3NOYW1lIiwiY29udGFpbmVyIiwibWFpbiIsImgxIiwidGl0bGUiLCJtYXBDb250YWluZXJTdHlsZSIsInpvb20iLCJtZW1vIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/FireWatcher.js\n");

/***/ }),

/***/ "./pages/fireWatcher.js":
/*!******************************!*\
  !*** ./pages/fireWatcher.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ FireWatcherPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _components_FireWatcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../components/FireWatcher */ \"./components/FireWatcher.js\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction FireWatcherPage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"title\", {\n                        children: \"WWS | Fire Watcher\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\pages\\\\fireWatcher.js\",\n                        lineNumber: 8,\n                        columnNumber: 17\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"meta\", {\n                        name: \"keyword\",\n                        content: \"WWS\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\pages\\\\fireWatcher.js\",\n                        lineNumber: 9,\n                        columnNumber: 17\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\pages\\\\fireWatcher.js\",\n                lineNumber: 7,\n                columnNumber: 13\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_FireWatcher__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\WWS\\\\wws\\\\wwsMk5\\\\nextjs-blog\\\\pages\\\\fireWatcher.js\",\n                lineNumber: 11,\n                columnNumber: 13\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9maXJlV2F0Y2hlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQW1EO0FBQ3ZCO0FBRWIsUUFBUSxDQUFDRSxlQUFlLEdBQUUsQ0FBQztJQUN0QyxNQUFNLDZFQUFDOzt3RkFFRUQsa0RBQUk7O2dHQUNBRSxDQUFLO2tDQUFDLENBQWtCOzs7Ozs7Z0dBQ3hCQyxDQUFJO3dCQUFDQyxJQUFJLEVBQUMsQ0FBUzt3QkFBQ0MsT0FBTyxFQUFDLENBQUs7Ozs7Ozs7Ozs7Ozt3RkFFckNOLCtEQUFXOzs7Ozs7O0FBR3hCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9maXJlV2F0Y2hlci5qcz8xMzk2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBGaXJlV2F0Y2hlciBmcm9tIFwiLi4vY29tcG9uZW50cy9GaXJlV2F0Y2hlclwiXHJcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZpcmVXYXRjaGVyUGFnZSgpe1xyXG4gICAgcmV0dXJuKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPldXUyB8IEZpcmUgV2F0Y2hlcjwvdGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8bWV0YSBuYW1lPVwia2V5d29yZFwiIGNvbnRlbnQ9XCJXV1NcIi8+XHJcbiAgICAgICAgICAgIDwvSGVhZD5cclxuICAgICAgICAgICAgPEZpcmVXYXRjaGVyLz5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn0iXSwibmFtZXMiOlsiRmlyZVdhdGNoZXIiLCJIZWFkIiwiRmlyZVdhdGNoZXJQYWdlIiwidGl0bGUiLCJtZXRhIiwibmFtZSIsImNvbnRlbnQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/fireWatcher.js\n");

/***/ }),

/***/ "@react-google-maps/api":
/*!*****************************************!*\
  !*** external "@react-google-maps/api" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@react-google-maps/api");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/fireWatcher.js"));
module.exports = __webpack_exports__;

})();